function GerarTabuada() {
    let numero = parseInt(document.getElementById('numero').value);
    let inicio = parseInt(document.getElementById('inicio').value);
    let fim = parseInt(document.getElementById('fim').value);

    if (isNaN(numero) || isNaN(inicio) || isNaN(fim)) {
        alert("Por favor, preencha todos os campos com números válidos.");
        return;
    }

    let tabuada = {
        numero: [],
        fator: [],
        resultado: []
    };

    for (let i = inicio; i <= fim; i++) {
        tabuada.numero.push(numero);
        tabuada.fator.push(i);
        tabuada.resultado.push(numero * i);
    }

    exibirTabuada(tabuada, numero, inicio, fim);
}

function exibirTabuada(tabuada, numero, inicio, fim) {
    let resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = '';

    if (tabuada.numero.length === 0) {
        resultadoDiv.innerHTML = '<p>Nenhuma tabuada gerada. Verifique os valores inseridos.</p>';
        return;
    }

    let introducao = `<p><strong>Tabuada do número: </strong>${numero}</p>
                      <p><strong>Intervalo da tabuada: </strong>De ${inicio} até ${fim}</p>`;

    let tabela = '<table>';
    tabela += '<tr><th>Número</th><th>Fator</th><th>Resultado</th></tr>';
    for (let i = 0; i < tabuada.numero.length; i++) {
        tabela += `<tr>
                    <td>${tabuada.numero[i]}</td>
                    <td>${tabuada.fator[i]}</td>
                    <td>${tabuada.resultado[i]}</td>
                   </tr>`;
    }
    tabela += '</table>';

    resultadoDiv.innerHTML = introducao + tabela;
}

function RecarregarPágina() {
    window.location.reload();
}
