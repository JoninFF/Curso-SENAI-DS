var lista = "";

function AdicionarNome(){

    var nome = document.getElementById("nome").value;
    
    lista += nome;

    lista += "\n";

    document.getElementById("mensagem").innerText = nome + " foi adicionado na lista.";

    document.getElementById("nome").value = "";
}

function ListarNomes(){
    document.getElementById("mensagem").innerText = " Os nomes adicionados foram: ";
    document.getElementById("lista").innerText = lista

}

function LimparNomes(){

    lista = "";
    document.getElementById("mensagem").innerText = " A lista foi apagada ";
    document.getElementById("lista").innerText = lista
    

}