var tentativa = 0

function ValidarLogin() {
    //Leia o usuario
    var usuario = document.getElementById("usuario").value;
    //Leia a senha
    var senha = document.getElementById("senha").value;

    var mensagem = "";

    if (tentativa < 3){

    //Se o usuario for "aluno" e a senha for "1234"
    if (usuario == "aluno" && senha == "1234"){
        mensagem = "Autenticado";
    } else { 
        tentativa += 1;
        mensagem = " Usuário ou senha inválidos "}
    }else {
        mensagem = " Número de tentativas excedido"
    }

    document.getElementById("tentativa").innerText = "Tentativas realizadas: " + tentativa + "/3";
    document.getElementById("mensagem").innerText = mensagem;

}