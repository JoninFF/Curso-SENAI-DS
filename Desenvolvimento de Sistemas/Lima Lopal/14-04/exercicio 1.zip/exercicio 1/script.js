function VerificarRadio(){

    let faixaEtaria = "";

    if(document.getElementById("ate14").checked){
        faixaEtaria = "criança"
    } else if(document.getElementById("ate25").checked){
        faixaEtaria = "jovem"
    } else if(document.getElementById("ate64").checked){
        faixaEtaria = "adulto"
    } else if(document.getElementById("65acima").checked){
        faixaEtaria = "idoso"
    } else {
        document.getElementById("respostaRadio").innerText = 'Insira sua idade'

        return
    }

    document.getElementById("respostaRadio").innerText = "Parabéns, você é " + faixaEtaria
    
}