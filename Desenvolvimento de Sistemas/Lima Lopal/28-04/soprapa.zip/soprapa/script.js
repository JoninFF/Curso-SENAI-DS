function SelecionarSalgado(){
    resposta = document.getElementById('resposta')
    resposta_img = document.getElementById("imagens")
    resposta.innerHTML = "";
    resposta_img.innerHTML = "";
    
    let lista_img = [];
    let lista = [];
    
     if(document.getElementById("coxinha").checked){
        lista.push("coxinha");
        lista_img.push("<img src='images.jpg'>");
     };
    
     if(document.getElementById("esfirra").checked){
        lista.push("esfirra");
        lista_img.push("<img src='Esfirra-de-carne-moida.jpg'>");

     };
    
     if(document.getElementById("quibe").checked){
        lista.push("quibe");
        lista_img.push("<img src='kibeimg.jpg'>");
    };
     for (let i = 0; i < lista.length; i++){
        document.getElementById('resposta').innerHTML += lista[i] + '<br>'
     }

     for (let i= 0; i < lista_img.length; i++){
        resposta_img.innerHTML += lista_img[i]
     }
    
}   
     
function LimparTela(){
 window.location.reload()
}