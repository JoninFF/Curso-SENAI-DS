function MontarTabuada(){
    var numero = document.getElementById("numero").value;

    if (numero < 1 || numero > 10) {
        alert("Por favor, informe um número entre 1 e 10");

        return;
    }

    var tabelaHTML ="";
    
    tabelaHTML += "<table>";
    tabelaHTML += "<tbody>";
    
    for (let i = 1; i <= 10; i++) {
        tabelaHTML += "<tr>";
        tabelaHTML += "<td>"+numero+"</td>";
        tabelaHTML += "<td>"+i+"</td>";
        tabelaHTML += "<td>"+numero*i+"</td>";
        tabelaHTML += "</tr>";
        
    }
    
    
    tabelaHTML += "</tbody>";
    tabelaHTML += "</table>";
    document.getElementById("divtabela").innerHTML = tabelaHTML;
}           