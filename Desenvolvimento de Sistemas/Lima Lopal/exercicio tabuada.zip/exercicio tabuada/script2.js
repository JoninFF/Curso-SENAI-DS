var numeroAleatorio = Math.floor(Math.random() * 100 + 1);

function TentarAdivinhar(){
    var tentativa = document.getElementById("tentativa").value
    if (tentativa > numeroAleatorio){
        document.getElementById("resultado").innerHTML = "Tente um número menor";
    }

    else if (tentativa < numeroAleatorio){
    document.getElementById("resultado").innerHTML = "Tente um número maior"

    }
    if(tentativa == numeroAleatorio){
        document.getElementById("resultado").innerHTML = "Voce Acertou"
    }

}