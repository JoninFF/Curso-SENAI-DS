function SelecionarSalgado(){

    var lista_salgados = " "

    if (document.getElementById("coxinha").checked){
        lista_salgados += "coxinha \n" 
        document.getElementById("imgc").style.visibility="visible"
    }
    if (document.getElementById("esfirra").checked){
        lista_salgados += "esfirra \n" 
        document.getElementById("imge").style.visibility="visible"
    }
    if (document.getElementById("quibe").checked){
        lista_salgados += "quibe \n"     
        document.getElementById("imgk").style.visibility="visible"

    } 
    
    if (lista_salgados == " ") {
        alert("Selecione um salgado")
        return
    
    }
    document.getElementById("resposta").innerText = "Voce selecionou: \n " + (lista_salgados) 

    document.getElementById('main').style.height = '350px'
}

function LimparTela(){
    window.location.reload()
}